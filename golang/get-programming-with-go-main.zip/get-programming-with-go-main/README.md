# Get Programming with Go

![Build and Test](https://github.com/nathany/get-programming-with-go/workflows/Build%20and%20Test/badge.svg)

Available from Manning Publications [https://www.manning.com/books/get-programming-with-go](https://www.manning.com/books/get-programming-with-go?utm_source=nathany&utm_medium=affiliate&utm_campaign=book_youngman_get_9_17_18&a_aid=nathany&a_bid=53f68821).

Try out these examples in The Go Playground: https://play.golang.org

If you downloaded this code from the Manning website, you can browse the latest version online at: https://github.com/nathany/get-programming-with-go.

### Contributing

Feel free to open an issue or ask questions on the Manning LiveBook: https://forums.manning.com/forums/get-programming-with-go.
