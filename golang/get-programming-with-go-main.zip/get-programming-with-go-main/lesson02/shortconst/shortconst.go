package main

func main() {
	const hoursPerDay, minutesPerHour = 24, 60
}
