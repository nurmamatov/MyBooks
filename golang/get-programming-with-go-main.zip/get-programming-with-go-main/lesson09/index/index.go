package main

import "fmt"

func main() {
	message := "shalom"
	c := message[5]
	fmt.Printf("%c\n", c)
}
