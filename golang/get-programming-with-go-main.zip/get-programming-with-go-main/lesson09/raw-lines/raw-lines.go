package main

import "fmt"

func main() {
	fmt.Println(`
		peace be upon you
		upon you be peace`)
}
