package main

import "fmt"

func main() {
	c := 'g'
	c = c - 'a' + 'A'
	fmt.Printf("%c", c)
}
