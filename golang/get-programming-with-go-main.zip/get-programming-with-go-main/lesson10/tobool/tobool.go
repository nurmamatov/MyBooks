package main

import "fmt"

func main() {
	yesNo := "no"

	launch := (yesNo == "yes")
	fmt.Println("Ready for launch:", launch)
}
