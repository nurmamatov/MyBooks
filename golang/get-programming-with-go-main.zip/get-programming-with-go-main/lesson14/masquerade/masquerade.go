package main

import "fmt"

var f = func() {
	fmt.Println("Dress up for the masquerade.")
}

func main() {
	f()
}
