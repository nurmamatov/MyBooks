package main

import (
	"fmt"
)

func main() {
	fmt.Println("Hello, Nathan")
	fmt.Println("你好 こんにちは Здравствуйте hola")
}
